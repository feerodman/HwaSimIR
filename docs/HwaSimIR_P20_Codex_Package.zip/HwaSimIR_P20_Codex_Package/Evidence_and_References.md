# 依据、已知事实与设计建议的区别

## 项目资料（本轮已读取）

main检索快照：`18a6f427e0aef731804d0951802979b044998106`。
仓库：`https://github.com/feerodman/HwaSimIR`。

### 最新功能和分域

`docs/HwaSimIR_P19_Closeout.md`、`docs/HwaSimIR_P19_Resumed_Test_Report.md`、`docs/HwaSimIR_P19_DDS_Domains.md`、`docs/HwaSimIR_P19_Source_Index.md`。

报告记录：稳定版为ARM24、Windows09、UI12；板端控制150/原视频1/客户1。分域、同PID恢复、客户独立输出、尾帧标准结束和回滚已有各自证据。真实客户现场故障码7根因、最终互通、硬解及屏幕呈现延迟未验证。

代码交叉检查：
- `DDS/Runtime/DdsRuntimeManager.{h,cpp}`：按域map、participantForDomain、一次全局Init/Finalize、0..232项目校验。
- `HwaSim_IR/Bin/Config/HwaSimIRRuntime.ini`：仓库控制/原视频默认150，客户域-1、默认Enable=false，输出worker已有4,5,6,7配置。

### 云与性能

`docs/HwaSimIR_P19_Presagis_Cloud_Findings.md`、`docs/HwaSimIR_P19_Resumed_Test_Report.md`。

报告没有跑Presagis性能基准，也没有还原其闭源实现。标准3D云puffs、共享资源与排序等结论来自本机随包文档/公开头文件/示例，不推广到所有Ondulus或SilverLining路径。

最新稳定版重云600帧记录：精跟39.22FPS、最大积压216帧、STOP约5385ms。此前仅精跟、大核绑定、RGBA/PBO、降低云附件分辨率等试验有明确无效/失真边界。不同运行不能拼成一个同条件实验。

代码交叉检查：
- `HwaSim_IR/HwaSim_IR/IR/IRCloudAppearance.h`：现有云描述、派生缓存和物理/显示资源参数。
- `HwaSim_IR/HwaSim_IR/IR/IRCloudPresentation.inl`：SetupCloudPresentation、UpdateCloudPresentation、原生尺寸外观附件、白云分支24步设置、共享几何/深度与显示-only声明。

`HwaSimIR_P19_Cloud_Deferred.md`明确是历史快照，不能替换最新恢复测试记录。

## 外部公开技术参考（不代表本项目已实现或通过）

1. Mark J. Harris / Anselmo Lastra，Real-Time Cloud Rendering，2001。
   作者项目页：`https://markmark.net/clouds/`。
   论文记录：`https://diglib.eg.org/items/0708aed8-5aaf-493e-a6f0-584ef145a039`。
   支持“预计算云光照、粒子/splats、按误差刷新impostor、对象穿云需前后切分”的公开技术路线；不证明RK3588能直接达到指定FPS，也不是Presagis全部内部实现说明。

2. Linux Kernel，CPU Performance Scaling。
   `https://www.kernel.org/doc/html/latest/admin-guide/pm/cpufreq.html`。
   支持按policy管理频率、核对related_cpus/可用governor、请求频率与实际频率区别。目标板内核暴露的功能需现场检测，不能用最新版文档假定旧板端功能全部存在。

3. Arm，关于Mali片元性能和overdraw的官方技术文章。
   `https://developer.arm.com/community/arm-community-blogs/b/mobile-graphics-and-gaming-blog/posts/new-mali-graphics-debugger-v1-2-features-improve-fragment-performance`。
   支持透明overdraw可能增加片元负载；不等于本机已安装或可使用该调试器。

## 本Prompt提出、仍待实现验证的部分

PuffHybrid/LegacyVolume名称、分层或有界光学厚度表示、近距混合、缓存失效策略、算法×调度四组合A/B及P20交付测试矩阵均属于实施建议。不是已存在配置、不是已通过结果，也不保证某一候选一定成为最终方案。

新的云表示允许合理的像素差异；必须独立验证外观、深度/透射正确性和真实性能，不能既宣称换了模型又宣称自动保持所有物理数值等价。
